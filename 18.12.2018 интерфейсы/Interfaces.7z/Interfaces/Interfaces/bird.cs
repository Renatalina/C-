﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    interface IFly
    {
        void Fly();
        
    }
    interface ISwim
    {
        void Swim();
    }
    interface IRun
    {
        bool Run(int n);
    }
   abstract class bird
    {
        protected  string name;
       // public abstract void Fly();
        public void IsEggs() { }
       // public virtual void Swim()
       // {

       // }
    }

    class Duck:bird, IFly, ISwim
    {
        public Duck()
        {
            name = "Duck";
        }
        public void Fly()
        {
            Console.WriteLine($"Duck is fly!");
        }
        public void Swim()
        {
            Console.WriteLine($"Duck is swim");
        }

    }
    class indoDuck : Duck
    {
       
    }

    class Penguin:bird, ISwim
    {
        public Penguin()
        {
            name = "Penguin";
        }
        //public override void Fly()
        //{
        //    throw new NotImplementedException();
        //}
        public void Swim()
        {
            Console.WriteLine($"Penguim is swim");
        }

    }
    class Ostrich:bird, IRun
    {
        public Ostrich()
        {
            name = "Ostrich";
        }
        //public override void Fly()
        //{
        //    throw new NotImplementedException();
        //}
        //public override void Swim()
        //{
        //    base.Swim();
        //}
        public bool Run(int speed)
        {
            Console.WriteLine($"Ostrich is run");
            return speed > 5 ? true : false;
        }

    }
    abstract class Insect
    {
        protected string name;
    }
    class Butterfly:Insect, IFly
    {
        public Butterfly ()
        {
            name = "Butterfly";
        }
        public void Fly()
        {
            Console.WriteLine($"{name}, is fly");
        }
    }
    class Plane : IFly
    {
        protected string name; 
        public Plane()
        {
            name = "Plane";
        }
        public void Fly()
        {
            Console.WriteLine($"Plane is fly");
        }
    }


}
