﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Kalendar
{
    class Mont
    { 
}
    class Program
    {
        class Month
        {
            public void run(DateTime day)
            {

                Console.Clear();

                int start = 1;//для вывода на экран с начала месяца
                int end = 31;// для конца месяца
                int color = 0;//для определения цвета

                ConsoleColor[] colors = (ConsoleColor[])ConsoleColor.GetValues(typeof(ConsoleColor));               
            
                if (day.Month == 3 || day.Month == 4 || day.Month == 5)
                {
                    color = 10;
                }
                if (day.Month == 1 || day.Month == 2 || day.Month == 12)
                {
                    color = 1;
                }
                if (day.Month == 6 || day.Month == 7 || day.Month == 8)
                {
                    color = 12;
                }
                if (day.Month == 9 || day.Month == 10 || day.Month == 11)
                {
                    color = 14;
                }
                Console.ForegroundColor = colors[color];



                switch (day.Month)//находим сколько дней в месяце
                {
                    case 1:
                    case 3:                    
                    case 5:                        
                    case 7:
                    case 8:
                    case 10:
                    case 12:
                        end = 31;
                        break;
                    case 2:
                        if (day.Year % 4 == 0 && day.Year % 100 == 0 && !(day.Year % 400 == 0))
                        {
                            end = 29;
                        }
                        else
                        {
                            end = 28;
                        }
                        break;
                    case 4:                       
                    case 6:
                    case 9:
                    case 11:
                        end = 30;
                        break;

                }
               
                DateTime T = new DateTime(day.Year, day.Month, 1);
                int a = Convert.ToInt32(T.DayOfWeek);//проверка, если первое число месяца это воскресенье
                if (a == 0)
                {
                    a = 7;
                }
                WriteLine(day.ToString());
                Write($"\n");
                Write($"Пн\t Вт\t Ср\t Чт\t Пт\t");
                Console.ForegroundColor = colors[7];//серый для выходных
                Write($"Сб\t Вс\n");
                Console.ResetColor();                
                Console.ForegroundColor = colors[color];// возвращае обычный цвет для всех остальных 
                for (int g = start; g < a; g++)
                {
                    Write($"\t ");

                }
                for (int i = start; i <= end; i++)
                {
                    Console.ForegroundColor = colors[color];
                    if ((a - 1 + i) % 7 == 0|| (a - 1 + i+1) % 7 == 0)
                    {
                        Console.ForegroundColor = colors[7];//выделяем серым два выходных. 
                        Console.ResetColor();

                    }
                        Write($"{i}\t ");
                    if ((a - 1 + i) % 7 == 0)
                    {
                        Write($"\n ");
                    }

                }
                Write($"\n\n\n\n\n\n\n ");

            }
        }
        static void Main(string[] args)
        {
            Month current = new Month();
            var dDay = DateTime.Now;
           
            current.run(dDay);//находим текущую дату
            
            
            
             while(true)
               {
                ConsoleKeyInfo key = ReadKey();
              
                            switch (key.Key)
                            {
                                case ConsoleKey.LeftArrow:
                                   dDay=dDay.AddMonths(-1);                      
                                   current.run(dDay);                       
                        break;
                                case ConsoleKey.UpArrow:
                        dDay = dDay.AddMonths(-6);
                                   current.run(dDay);                       
                        break;
                                case ConsoleKey.RightArrow:
                        dDay = dDay.AddMonths(1);                                   
                                   current.run(dDay);             
                        break;
                                 case ConsoleKey.DownArrow:
                        dDay = dDay.AddMonths(6);
                                   current.run(dDay);                    
                        break;
                              default:
                                   break;
                            }
               
               } 


        }
    }
}
