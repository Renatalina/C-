﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Garbage
{

    /*
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Демонстрация System.GC");
            WriteLine($"Максимальное поколение: {GC.MaxGeneration}");

            GarbageHelper hlp = new GarbageHelper();
            // узнаем поколение, в котором находится объект
            WriteLine($"Поколение объекта: {GC.GetGeneration(hlp)}");
            // количество занятой памяти
            WriteLine($"Занято памяти (байт): {GC.GetTotalMemory(false)}");

            hlp.MakeGarbage(); // создаем мусор
            WriteLine($"Занято памяти (байт): {GC.GetTotalMemory(false)}");

            GC.Collect(0); // вызываем явный сбор мусора в поколении 0

            WriteLine($"Занято памяти (байт): {GC.GetTotalMemory(false)}");

            WriteLine($"Поколение объекта: {GC.GetGeneration(hlp)}");

            GC.Collect(); // вызываем явный сбор мусора во всех поколениях

            WriteLine($"Занято памяти (байт): {GC.GetTotalMemory(false)}");

            WriteLine($"Поколение объекта: {GC.GetGeneration(hlp)}");
        }
    }

    // Вспомогательный класс для создания мусора
    class GarbageHelper
    {
        // Метод, создающий мусор
        public void MakeGarbage()
        {
            for (int i = 0; i < 1000; i++)
            {
                Person p = new Person();
            }
        }
        class Person
        {
            string _name;
            string _surname;
            byte _age;
        }
    }*/

    /*
class MyClass:IDisposable
{
    ~MyClass()
    {
        WriteLine($"Finaly");
        Beep(659,300);
        Beep(659, 300);
        Beep(659, 300);
    }
    public void Dispose()
    {
        WriteLine($"Despose cleare");
    }
}
class DisposeExample
{
    public void Dispose()
    {
        WriteLine($"Despose cleare");
    }
}
class Program
{
    static void Main(string[] args)
    {
        MyClass v = new MyClass();
        v.Dispose();
        v = null;
        // GC.Collect(0);//это вызов принудительного сборщика мусора

        DisposeExample test = null;
        try
        {
            test = new DisposeExample();
        }
        catch(Exception)
        {
            throw;
        }
        finally
        {
            if(test !=null)
            test.Dispose();
        }

        using (DisposeExample test1=new DisposeExample())// эта констрацкция только для классов у которых реализован метод Диспосе
        {


        } 

    }
}

*/

    /*
        class Program
        {
            static void Main(string[] args)
            {

            }
        }*/


    /*Создать класс Студент, который содержит список оценок.
Создать класс Группа, в которой находится список студентов. Создать метод выставления оценок студентов группы.
Создать класс, который позволяет хранить и получать информацию о студентах, получивших определенные оценки (1, 2, 3, 4, 5).*/


    class Student
    {
        List<int> score = new List<int>();
        public string name;
    }

    class GroupStudent:Student
    {
        List<Student> students = new List<Student>();
        public void AddStudent(string Name)
        {

            students[Name].Add(new Student { name=Name});
        }
    }

}
