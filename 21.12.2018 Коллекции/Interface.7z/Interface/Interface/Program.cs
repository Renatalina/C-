﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.Collections;

namespace Interface
{
    /*
        interface IFly
        {
            void Fly();
        }

        interface ISwim
        {
            void Swim();
        }

        interface IRun
        {
            bool Run(int n);
        }
        abstract class Bird
        {
            protected string name;

            public void IsEggs() { }

            //public abstract void Fly();

            //public virtual void Swim()
            //{
            //    // ??
            //}
        }

        class Duck : Bird, IFly, ISwim
        {
            public Duck()
            {
                name = "Duck";
            }

            public void Fly()
            {
                Console.WriteLine($"{name} fly");
            }

            public void Swim()
            {
                Console.WriteLine($"{name} swim");
            }
        }

        class Penguin : Bird, ISwim
        {
            public Penguin()
            {
                name = "Penguin";
            }
            //public override void Fly()
            //{ // ???
            //    throw new NotImplementedException();
            //}

            public void Swim()
            {
                Console.WriteLine($"{name} swim");
            }
        }

        class Ostrich : Bird, IRun
        {
            public Ostrich()
            {
                name = "Ostrich";
            }

            public bool Run(int speed)
            {
                if (speed > 0)
                {
                    Console.WriteLine($"{name} run");
                    return true;
                }
                return false;
            }
        }

        abstract class Insect
        {
            protected string name;
        }

        class Butterfly : Insect, IFly
        {
            public Butterfly()
            {
                name = "Butterfly";
            }
            public void Fly()
            {
                Console.WriteLine($"{name} fly");
            }
        }

        class Plane : IFly
        {
            public void Fly()
            {
                Console.WriteLine($"Plane fly");
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                //Bird bird = new Duck();

                IFly[] fly = { new Plane(), new Duck(), new Butterfly() };

                foreach (IFly item in fly)
                {
                    item.Fly();
                }

                Bird[] birds = { new Penguin(), new Duck(), new Ostrich() };

                foreach (Bird item in birds)
                {
                    //((IFly)item).Fly(); // try catch

                    if (item is IFly)
                    {
                        (item as IFly).Fly();
                    }
                }

                Console.ReadKey();
            }
        }

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    */
    /*

    namespace ConsoleCSharp
        {
            abstract class Human
            {
                public string FirstName { get; set; }
                public string LastName { get; set; }
                public DateTime BirthDate { get; set; }
                public override string ToString()
                {
                    return $"\nФамилия: {LastName} Имя: {FirstName} Дата рождения: {BirthDate.ToLongDateString()}";
                }
            }
            abstract class Employee : Human
            {
                public string Position { get; set; }
                public double Salary { get; set; }

                public override string ToString()
                {
                    return base.ToString() + $"\nДолжность: {Position} Заработная плата: {Salary} $";
                }
            }
            interface IWorker
            {
                bool IsWorking { get; }
                string Work();
            }
            interface IManager
            {
                IWorker[] ListOfWorkers { get; set; }
                void Organize();
                void MakeBudget();
                void Control();
            }
            class Director : Employee, IManager
            {
                public IWorker[] ListOfWorkers { get; set; }

                public void Control()
                {
                    WriteLine("Контролирую работу!");
                }

                public void MakeBudget()
                {
                    WriteLine("Формирую бюджет!");
                }

                public void Organize()
                {
                    WriteLine("Организую работу!");
                }
            }

            class Seller : Employee, IWorker
            {
                bool isWorking = true;

                public bool IsWorking
                {
                    get
                    {
                        return isWorking;
                    }
                }

                public string Work()
                {
                    return "Продаю товар!";
                }
            }

            class Cashier : Employee, IWorker
            {
                public bool IsWorking { get; } = true;

                public string Work()
                {
                    return "Принимаю оплату за товар!";
                }
            }

            class Storekeeper : Employee, IWorker
            {
                public bool IsWorking { get; set; }

                public string Work()
                {
                    return "Учитываю товар!";
                }
            }
            class Program
            {
                static void Main(string[] args)
                {
                    Director director = new Director { LastName = "Doe", FirstName = "John", BirthDate = new DateTime(1998, 10, 12), Position = "Директор", Salary = 12000 };

                    IWorker seller = new Seller { LastName = "Beam", FirstName = "Jim", BirthDate = new DateTime(1956, 5, 23), Position = "Продавец", Salary = 3780 };

                    if (seller is Employee)
                        WriteLine($"Заработная плата продавца: {(seller as Employee).Salary}"); // приведение интерфейсной ссылки к классу Employee

                    director.ListOfWorkers = new IWorker[] {
                    seller,
                    new Cashier { LastName = "Smith", FirstName = "Nicole", BirthDate = new DateTime(1956, 5, 23), Position = "Кассир", Salary = 3780 },
                    new Storekeeper { LastName = "Ross", FirstName = "Bob", BirthDate = new DateTime(1956, 5, 23), Position = "Кладовщик", Salary = 4500 }
                };

                    WriteLine(director);
                    if (director is IManager) // использование оператора is
                    {
                        director.Control();
                    }

                    foreach (IWorker item in director.ListOfWorkers)
                    {
                        WriteLine(item);

                        if (item is Storekeeper)
                        {
                            (item as Storekeeper).IsWorking = true;
                        }

                        if (item.IsWorking)
                        {
                            WriteLine(item.Work());
                        }
                    }
                }
            }
        }
        */

    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /*

    namespace SimpleProject
        {
            interface IIndexer
            {
                string this[int index]
                {
                    get;
                    set;
                }
                string this[string index]
                {
                    get;
                }
            }

            enum Numbers { one, two, three, four, five };

            class IndexerClass : IIndexer
            {
                string[] _names = new string[5];

                public string this[int index]
                {
                    get
                    {
                        return _names[index];
                    }
                    set
                    {
                        _names[index] = value;
                    }
                }

                public string this[string index]
                {
                    get
                    {
                        if (Enum.IsDefined(typeof(Numbers), index))
                            return _names[(int)Enum.Parse(typeof(Numbers), index)];
                        else
                            return "";
                    }
                }

                public IndexerClass()
                {
                    // запись значений, используя индексатор с целочисленным параметром
                    this[0] = "Bob";
                    this[1] = "Candice";
                    this[2] = "Jimmy";
                    this[3] = "Joey";
                    this[4] = "Nicole";
                }
            }
            class Program
            {
                static void Main(string[] args)
                {
                    IndexerClass indexerClass = new IndexerClass();

                    WriteLine("\t\tВывод значений\n");
                    WriteLine("Использование индексатора с целочисленным параметром:");
                    for (int i = 0; i < 5; i++)
                    {
                        WriteLine(indexerClass[i]);
                    }

                    WriteLine("\nИспользование индексатора со строковым параметром:");
                    foreach (string item in Enum.GetNames(typeof(Numbers)))
                    {
                        WriteLine(indexerClass[item]);
                    }
                }
            }
        }
    */
    /*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

                    Написать приложение «Праздничное небо».
    В праздник в небе над городом можно наблюдать фейерверки, воздушные шары, группы парашютистов.
    Эти объекты никак не связаны иерархией наследования, но все же ваше приложение должно реализовать объект «Праздничное небо», который является коллекцией «объектов праздничного неба» (подсказка – коллекцией/массивом интерфейсов).
    В любой момент времени в небе можно наблюдать только один «объект праздничного неба», который пролетев по небу, исчезает и ему на смену приходит другой объект.
    При старте приложения коллекция «Праздничное небо» заполняется случайным образом и случайным количеством «объектов праздничного неба». После чего начинается шоу.
    Необходимо реализовать следующие виды фейерверков – крест, диагональный крест, цветок.
    Виды парашютистов – группа «треугольник», группа «ромб». Виды воздушных шаров – цветок, хаос.
    Продумать возможную иерархию родственных объектов.

    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    */
    /*
    class MyClass
    {
        private DateTime _date;
        public static MyClass operator +(MyClass my, int n)
        {
            return my;
        }
        public void Show()
        {

        }
    }

    MyClass myClass = new MyClass();

            while (true)
            {
                ConsoleKeyInfo keyInfo = Console.ReadKey();

                switch (keyInfo.Key)
                {
                    case ConsoleKey.PageUp:
                        myClass += 12;
                        break;
                    case ConsoleKey.PageDown:
                        break;
                    case ConsoleKey.LeftArrow:
                        break;
                    case ConsoleKey.RightArrow:
                        break;
                    case ConsoleKey.UpArrow:
                        break;
                    case ConsoleKey.DownArrow:
                        break;
                }
            }

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
    /*
    interface IA
    {
        string A1(int n);
    }

    interface IB
    {
        int B1(int n);
        void B2();
    }

    interface IC : IA, IB
    {
        void C1(int n);
    }

    class InherInterface : IC
    {
        public string A1(int n)
        {
            throw new NotImplementedException();
        }

        public int B1(int n)
        {
            throw new NotImplementedException();
        }

        public void B2()
        {
            throw new NotImplementedException();
        }

        public void C1(int n)
        {
            throw new NotImplementedException();
        }
    }


        */


    /*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BirdInterface
{
    interface IFly
    {
        void Fly();
    }

    interface ISwim
    {
        void Swim();
    }

    interface IRun
    {
        void Run();
    }

    abstract class Bird
    {
        protected string name;

        public void IsEggs() { }

        //public abstract void Fly(); - проблема, так как существуют птицы, которые не летают - решение - Interface
    }

    class Duck : Bird, IFly, ISwim
    {
        public Duck()
        {
            name = "Duck";
        }
        public void Fly() { Console.WriteLine(name); }
        public void Swim() { }
    }

    class Penguin : Bird, ISwim
    {
        public Penguin()
        {
            name = "Penguin";
        }

        public void Swim() { }
    }

    class Ostrich : Bird, IRun // страус
    {
        public Ostrich()
        {
            name = "Ostrich";
        }
        public void Run() { }
    }

    abstract class Insect // насекомое
    {
        protected string name;
    }

    class Butterfly : Insect, IFly
    {
        public Butterfly()
        {
            name = "Butterfly";
        }

        public void Fly() { Console.WriteLine(name); }
    }

    class Plane : IFly
    {
        string name = "Plane";
        public void Fly() { Console.WriteLine(name); }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IFly[] iFly = { new Duck(), new Butterfly(), new Plane() };

            foreach (IFly item in iFly)
            {
                item.Fly();
            }

            // применение is и as
            Bird[] birds = { new Penguin(), new Ostrich(), new Duck() };

            foreach (Bird item in birds)
            {
                // необходимо вызвать метод Fly()
                if (item is IFly)
                {
                    (item as IFly).Fly();
                }
            }

            Console.Read();
        }
    }
}

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
    /*
    using System;
    using static System.Console;

    namespace SimpleProject
    {
        abstract class Human
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public DateTime BirthDate { get; set; }
            public override string ToString()
            {
                return $"\nФамилия: {LastName} Имя: {FirstName} Дата рождения: {BirthDate.ToLongDateString()}";
            }
        }
        abstract class Employee : Human
        {
            public string Position { get; set; }
            public double Salary { get; set; }

            public override string ToString()
            {
                return base.ToString() + $"\nДолжность: {Position} Заработная плата: {Salary} $";
            }
        }
        interface IWorker
        {
            bool IsWorking { get; }
            string Work();
        }
        interface IManager
        {
            IWorker[] ListOfWorkers { get; set; }
            void Organize();
            void MakeBudget();
            void Control();
        }
        class Director : Employee, IManager
        {
            public IWorker[] ListOfWorkers { get; set; }

            public void Control()
            {
                WriteLine("Контролирую работу!");
            }

            public void MakeBudget()
            {
                WriteLine("Формирую бюджет!");
            }

            public void Organize()
            {
                WriteLine("Организую работу!");
            }
        }

        class Seller : Employee, IWorker
        {
            bool isWorking = true;

            public bool IsWorking
            {
                get
                {
                    return isWorking;
                }
            }

            public string Work()
            {
                return "Продаю товар!";
            }
        }

        class Cashier : Employee, IWorker
        {
            bool isWorking = true;
            public bool IsWorking
            {
                get
                {
                    return isWorking;
                }
            }

            public string Work()
            {
                return "Принимаю оплату за товар!";
            }
        }

        class Storekeeper : Employee, IWorker
        {
            bool isWorking = true;
            public bool IsWorking
            {
                get
                {
                    return isWorking;
                }
            }

            public string Work()
            {
                return "Учитываю товар!";
            }
        }
        class Program
        {
            static void Main(string[] args)
            {
                Director director = new Director { LastName = "Doe", FirstName = "John", BirthDate = new DateTime(1998, 10, 12), Position = "Директор", Salary = 12000 };

                IWorker seller = new Seller { LastName = "Beam", FirstName = "Jim", BirthDate = new DateTime(1956, 5, 23), Position = "Продавец", Salary = 3780 };

                if (seller is Employee)
                    WriteLine($"Заработная плата продавца: {(seller as Employee).Salary}"); // приведение интерфейсной ссылки к классу Employee

                director.ListOfWorkers = new IWorker[] {
                    seller,
                    new Cashier { LastName = "Smith", FirstName = "Nicole", BirthDate = new DateTime(1956, 5, 23), Position = "Кассир", Salary = 3780 },
                    new Storekeeper { LastName = "Ross", FirstName = "Bob", BirthDate = new DateTime(1956, 5, 23), Position = "Кладовщик", Salary = 4500 }
                };

                WriteLine(director);
                if (director is IManager) // использование оператора is
                {
                    director.Control();
                }

                foreach (IWorker item in director.ListOfWorkers)
                {
                    WriteLine(item);

                    if (item.IsWorking)
                    {
                        WriteLine(item.Work());
                    }
                }
            }
        }
    }

    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        interface IA
        {
            void Show();
        }
        interface IB
        {
            void Show();
        }
        interface IC
        {
            void Show();
        }

        class Realization : IA, IB, IC
        {
            public void Show()
            {
                Console.WriteLine("IC");
            }

            void IA.Show()
            {
                Console.WriteLine("IA");
            }

            void IB.Show()
            {
                Console.WriteLine("IB");
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Realization realization = new Realization();
                realization.Show();

                IA iA = new Realization();
                iA.Show();

                (realization as IB).Show();

                Console.ReadKey();
            }
        }

    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    */
    /*
    class StudentCard
    {
        public int Number { get; set; }
        public string Series { get; set; }

        public override string ToString()
        {
            return $"Студенческий билет: {Series} {Number}";
        }
    }

    -----------------------------------------------------------------------------------


    class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
        public StudentCard StudentCard { get; set; }

        public override string ToString()
        {
            return $"Фамилия: {LastName}, Имя: {FirstName}, Родился: {BirthDate.ToLongDateString()}, {StudentCard}";
        }
    }

    -------------------------------------------------------------------------------------

    class Auditory
    {
        Student[] students =
            {
            new Student {
                FirstName ="John",
                LastName ="Miller",
                BirthDate =new DateTime(1997,3,12),
                StudentCard =new StudentCard { Number=189356, Series="AB" }
            },
            new Student {
                FirstName ="Candice",
                LastName ="Leman",
                BirthDate =new DateTime(1998,7,22),
                StudentCard =new StudentCard { Number=345185, Series="XA" }
            },
            new Student {
                FirstName ="Joey",
                LastName ="Finch",
                BirthDate =new DateTime(1996,11,30),
                StudentCard =new StudentCard { Number=258322, Series="AA" }
            },
            new Student {
                FirstName ="Nicole",
                LastName ="Taylor",
                BirthDate =new DateTime(1996,5,10),
                StudentCard =new StudentCard { Number=513484, Series="AA" }
            }
        };
        public void Sort()
        {
            Array.Sort(students);
        }
    }

    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    using System;
    using static System.Console;

    namespace SimpleProject
    {
        class Child:ICloneable
        {
            public string Name { get; set; }
            public int Age { get; set; }

            public object Clone()
            {
                return this.MemberwiseClone();
            }

            public override string ToString()
            {
                return $"Имя: {Name}, Возраст: {Age}";
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Child child1 = new Child { Name = "Arthur", Age = 12 };

                WriteLine("Начальные значения:");
                Child child2 = (Child)child1.Clone();
                WriteLine($"Ребенок №1: {child1}");
                WriteLine($"Ребенок №2: {child2}");

                child2.Age = 14; // изменяем возраст

                WriteLine("\nЗначения после изменения возраста:");
                WriteLine($"Ребенок №1: {child1}");
                WriteLine($"Ребенок №2: {child2}");
            }
        }
    }*/
    /*
      class StudentCard
      {
          public int Number { get; set; }
          public string Series { get; set; }

          public override string ToString()
          {
              return $"Студенческий билет: {Series} {Number}";
          }
      }

      class Student : IComparable, ICloneable
      {
          public string FirstName { get; set; }
          public string LastName { get; set; }
          public DateTime BirthDate { get; set; }
          public StudentCard StudentCard { get; set; }
          public object Clone()
          {
              //return MemberwiseClone();
              Student student = (Student)this.MemberwiseClone();
              student.StudentCard = new StudentCard
              {
                  Series = this.StudentCard.Series,
                  Number = this.StudentCard.Number
              };
              return student;
          }


          public int CompareTo(object obj)
          {
              if (obj is Student student)
              {
                  return LastName.CompareTo(student.LastName);
              }
              //if (obj is Student)
              //{
              //    return LastName.CompareTo((obj as Student).LastName);
              //}
              throw new ArgumentException();
          }

          public override string ToString()
          {
              return $"Фамилия: {LastName}, Имя: {FirstName}, Родился: {BirthDate.ToLongDateString()}, {StudentCard}";
          }
      }
      /*
      class Auditory : IEnumerable
      {
          private Student[] students =
              {
          new Student {
              FirstName ="John",
              LastName ="Miller",
              BirthDate =new DateTime(1997,3,12),
              StudentCard =new StudentCard { Number=189356, Series="AB" }
          },
          new Student {
              FirstName ="Candice",
              LastName ="Leman",
              BirthDate =new DateTime(1998,7,22),
              StudentCard =new StudentCard { Number=345185, Series="XA" }
          },
          new Student {
              FirstName ="Joey",
              LastName ="Finch",
              BirthDate =new DateTime(1996,11,30),
              StudentCard =new StudentCard { Number=258322, Series="AA" }
          },
          new Student {
              FirstName ="Nicole",
              LastName ="Taylor",
              BirthDate =new DateTime(1996,5,10),
              StudentCard =new StudentCard { Number=513484, Series="AA" }
          }
      };

          IEnumerator IEnumerable.GetEnumerator()
          {
              return students.GetEnumerator();
          }

          public void Sort()
          {
              Array.Sort(students);
          }
          public void Sort(IComparer comparer)
          {
              Array.Sort(students, comparer);
          }
      }

      class DateComparer : IComparer
      {
          public int Compare(object x, object y)
          {
              if (x is Student && y is Student)
              {
                  return DateTime.Compare((x as Student).BirthDate, (y as Student).BirthDate);
              }

              throw new ArgumentException();
          }
      }
      */
    /*
    class Program
    {
        static void Main(string[] args)
        {
            /* Auditory auditory = new Auditory();

             auditory.Sort();

             foreach (Student item in auditory)
             {
                 Console.WriteLine(item);
             }

             Console.WriteLine("\n+++++++++++++++++++\n");

             //IComparer comparer = new DateComparer();
             //auditory.Sort(comparer);

             auditory.Sort(new DateComparer());

             foreach (Student item in auditory)
             {
                 Console.WriteLine(item);
             }

     */
    /*
           Student student1 = new Student
           {
               FirstName = "Viski",
               LastName = "Nata",
               BirthDate = new DateTime(1986, 2, 14),
               StudentCard = new StudentCard
               {
                   Number = 31426,
                   Series = "NV"
               }
           };

           Student student2 = (Student)student1.Clone();

           student2.FirstName = "Kusx";
           student2.LastName = "Igor";
           student2.BirthDate = new DateTime(1971, 8, 6);
           student2.StudentCard.Number = 2956;
           student2.StudentCard.Series = "IO";
           Console.WriteLine($"Student1:{student1}");
           Console.WriteLine($"Student2:{student2}");
           Console.ReadKey();
       }
   }

   */
    /*
     class Program
     {
         static void Main(string[] args)
         {

             ArrayList arrayList = new ArrayList();
             arrayList.Add(4);
             arrayList.Add(new DivideByZeroException());
             arrayList.Add("Hello");
             arrayList.Add(3.14159);

             arrayList.Sort();
             foreach(object iteam in arrayList)//будет ошибка так как в  arrayList.Add("Hello");  arrayList.Add(3.14159);
                 //тут разные типы данных  Неело и 3,14159 ;он не знает к кому приводить.
             {
                 WriteLine(iteam); 
             }
         }



     }
     */

    class Program
    {
        /*
        static void Main(string[] args)
    {
        Write("Исходная коллекция: ");
        ArrayList arrayList = new ArrayList(new int[] { 1, 2, 3, 4 });
        foreach (int i in arrayList)
        {
            Write($"{i} ");
        }

        Write("\n\nВставка элемента: ");
        arrayList.Insert(2, "Hello");
        foreach (object item in arrayList)
        {
            Write($"{item} ");
        }

        Write("\n\nУдаление элемента: ");
        arrayList.RemoveAt(3);
        foreach (object item in arrayList)
        {
            Write($"{item} ");
        }

        WriteLine("\n\nИндекс элемента \"Hello\": " + arrayList.IndexOf("Hello"));

        Write("\nПолучение диапазона: ");
        ArrayList days = new ArrayList(new string[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" });
        ArrayList onlyWork = new ArrayList(days.GetRange(1, 5));
        foreach (string s in onlyWork)
        {
            Write($"{s} ");
        }

        Write("\n\nСортировка коллекции: ");
        onlyWork.Sort();
        foreach (string s in onlyWork)
        {
            Write($"{s} ");
        }

        WriteLine();
    }
    */
    class Car
        {
            public ConsoleColor Color;
        }
        static void Main(string[] args)
        {

            /*
            Stack stak = new Stack();
            stak.Push(34);
            stak.Push(4);
            stak.Push(3);
            stak.Push(14);

            WriteLine(stak.Peek());
            WriteLine(stak.Pop());
            WriteLine("-------------------");
            if (stak.Contains(34))
            {
                foreach(var item in stak)
                {
                    WriteLine(item);
                }
            }
            */
            /*
            Queue queue = new Queue();
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Ok", 23);
            hashtable.Add(12, "Hello");
            hashtable.Add(12.45, 23.03);
            if (hashtable.ContainsKey(12)==false)
            {
                hashtable.Add(12, 23.03);
            }

            WriteLine(hashtable[12]);
            foreach(var item in hashtable.Keys)
            {
                WriteLine(hashtable[item]);
            }
            */

            List<int> vs = new List<int>();
            List<int> vs2 = new List<int> { 32,23,56,12 };

            vs.Add(501);
            vs.Add((int)56.2);
            Random ren = new Random();
            List<Car> cars = new List<Car>();
            cars.Add(new Car { Color =(ConsoleColor) Enum.GetValues(typeof(ConsoleColor)).GetValue(ren.Next(0, 15))});

            Console.ForegroundColor=cars[0].Color;
            Console.ForegroundColor = Enum.GetValues(typeof(ConsoleColor)).GetValue(ren.Next(0, 15));
            WriteLine(cars[0].Color);

        }

}

}
